clear all; close all; clc;
% plot showing the increase in power law exponent at ~145m: note the order 
% of magnitude increase in the variance of xi between 140-145m & 145-150m

cd ../processed_profile_mat_files

% load LISST profiles of xi
load xi2.mat;
load xi4.mat;
load xi6.mat;
z = [z2; z4; z6]'; x = [x2 x4 x6];
clear *2 *4 *6;

Z = 0:5:250;
for i = 1:length(Z)-1;
    v(i) = nanvar(x(z>Z(i) & z<Z(i+1)));
end
Z = Z(1:end-1)+2.5;
clear i;

scatter(Z,v);
grid minor
axis([0 Inf 0 .75])

cd ../code