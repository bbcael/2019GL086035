clear all; close all; clc;

% data is from first deployment, first depth (75m), first trap (A), first
% rep. try for others from raw data. plot shows volume computed for each
% bin and scan -- using the trap blank, volume is detected in bins 7 & up.
% t-test shows that the volume detected is significantly different than
% zero.

cd ../sed_trap_mat_files

load bin_choice_example.mat;


plot(1:10,A_75_1_rep1(:,1:10));
ylabel('volume')
xlabel('bin')

for i = 1:32;
h(i) = ttest(A_75_1_rep1(:,i),0,'Alpha',.01);
end
clear i;

cd ../code