close all; clear all; clc;

cd ../processed_trap_mat_files

% deployment times and trap heights from sediment trap log sheet
t1 = 3.39;
t2 = 3.04;
h1_75 = [.35 .335 .345 .35 .36 .34 .522 .522 .522 .395 .385 .365];
h2_75 = [.4 .44 .41 .42 .41 .522 .5064 .5064 .4 .43 .41];
h1_150 = [.325 .33 .465 .19 .32 .335 .5346 .5224 .5173 .38 .36 .355];
h2_150 = [.392 .42 .4 .37 .385 .5282 .5308 .5 .4 .3875 .401];
h1_300 = [.34 .345 .365 .33 .345 .35 .5385 .5256 .5359 .37 .365 .39];
h2_300 = [.382 .406 .379 .38 .398 .5231 .5385 .5 .38 .382 .36];

% load all data
load 1_75.mat;
F_1_75 = V.*1000.*h1_75./t1;
load 2_75.mat;
F_2_75 = V.*1000.*h2_75./t2;
load 1_150.mat;
F_1_150 = V.*1000.*h1_150./t1;
load 2_150.mat;
F_2_150 = V.*1000.*h2_150./t2;
load 1_300.mat;
F_1_300 = V.*1000.*h1_300./t1;
load 2_300.mat;
F_2_300 = V.*1000.*h2_300./t2;

% remove outliers
F_1_150(F_1_150>1500) = NaN;
F_1_300(F_1_300>1500) = NaN;
F_1_75(F_1_75>4000) = NaN;
F_2_150(F_2_150>3000) = NaN;
F_2_300(F_2_300>1500) = NaN;
F_2_75(F_2_75>4000) = NaN;

clearvars -EXCEPT F*;


%%

subplot(121)
% fits from regression as described in text using curve fitting toolbox
l1 = plot(1634.*exp(-(65:310).*.009349),65:310,'-.','linewidth',2,'color',[.75 .75 .75]);
hold on

[q1,ind] = sort(nanmean(F_1_75,1));
qq1 = nanstd(F_1_75,1);
errorbar(q1,linspace(65,74.5,12),qq1(ind),'horizontal','+k')
hold on
wm = sum(q1./(qq1.^2))./sum((qq1.^(-2)))
ws = sqrt(sum((q1-wm).^2.*(qq1.^(-2)))./sum((qq1.^(-2))))./sqrt(length(q1))
l2 = errorbar(wm,70,ws,'horizontal','ok','color',[.59 .07 .39],'markersize',15,'markerfacecolor',[.59 .07 .39],'linewidth',3)

m75 = nanmean(F_1_75(:)); s75 = nanstd(F_1_75(:));

[q2,ind] = sort(nanmean(F_1_150,1));
qq2 = nanstd(F_1_150,1);
errorbar(q2,linspace(140,149.5,12),qq2(ind),'horizontal','+k')
wm2 = sum(q2./(qq2.^2))./sum((qq2.^(-2)))
ws2 = sqrt(sum((q2-wm2).^2.*(qq2.^(-2)))./sum((qq2.^(-2))))./sqrt(length(q2))
errorbar(wm2,145,ws2,'horizontal','ok','color',[.59 .07 .39],'markersize',15,'markerfacecolor',[.59 .07 .39],'linewidth',3)

m150 = nanmean(F_1_150(:)); s150 = nanstd(F_1_150(:));

[q3,ind] = sort(nanmean(F_1_300,1));
qq3 = nanstd(F_1_300,1);
errorbar(q3,linspace(290,299.5,12),qq3(ind),'horizontal','+k')
wm3 = sum(q3./(qq3.^2))./sum((qq3.^(-2)))
ws3 = sqrt(sum((q3-wm3).^2.*(qq3.^(-2)))./sum((qq3.^(-2))))./sqrt(length(q3))
errorbar(wm3,295,ws3,'horizontal','ok','color',[.59 .07 .39],'markersize',15,'markerfacecolor',[.59 .07 .39],'linewidth',3)
set(gca,'ydir','reverse')

set(gca,'TickLabelInterpreter','latex','FontSize',16)
xlabel('volume flux [$\mu$L/m$^2$d]','Interpreter','latex','FontSize',20)
ylabel('depth [m]','Interpreter','latex','FontSize',20)
box on

zz = [75 150 300]; ww = [wm wm2 wm3]; ss = [ws ws2 ws3].^(-2); 

[q1,ind] = sort(nanmean(F_2_75,1));
qq1 = nanstd(F_2_75,1);
errorbar(q1,linspace(75.5,85,11),qq1(ind),'horizontal','+k')
hold on
wm = sum(q1./(qq1.^2))./sum((qq1.^(-2)))
ws = sqrt(sum((q1-wm).^2.*(qq1.^(-2)))./sum((qq1.^(-2))))./sqrt(length(q1))
l3 = errorbar(wm,80,ws,'horizontal','ok','color',[0.8477 0.3281 0.0977],'markersize',15,'markerfacecolor',[0.8477 0.3281 0.0977],'linewidth',3)

m75 = nanmean(F_2_75(:)); s75 = nanstd(F_2_75(:));

[q2,ind] = sort(nanmean(F_2_150,1));
qq2 = nanstd(F_2_150,1);
errorbar(q2,linspace(150.5,160,11),qq2(ind),'horizontal','+k')
wm2 = sum(q2./(qq2.^2))./sum((qq2.^(-2)))
ws2 = sqrt(sum((q2-wm2).^2.*(qq2.^(-2)))./sum((qq2.^(-2))))./sqrt(length(q2))
errorbar(wm2,155,ws2,'horizontal','ok','color',[0.8477 0.3281 0.0977],'markersize',15,'markerfacecolor',[0.8477 0.3281 0.0977],'linewidth',3)

m150 = nanmean(F_2_150(:)); s150 = nanstd(F_2_150(:));

[q3,ind] = sort(nanmean(F_2_300,1));
qq3 = nanstd(F_2_300,1);
errorbar(q3,linspace(300.5,310,11),qq3(ind),'horizontal','+k')
wm3 = sum(q3./(qq3.^2))./sum((qq3.^(-2)))
ws3 = sqrt(sum((q3-wm3).^2.*(qq3.^(-2)))./sum((qq3.^(-2))))./sqrt(length(q3))
errorbar(wm3,305,ws3,'horizontal','ok','color',[0.8477 0.3281 0.0977],'markersize',15,'markerfacecolor',[0.8477 0.3281 0.0977],'linewidth',3)
set(gca,'ydir','reverse')

box on

m300 = nanmean(F_2_300(:)); s300 = nanstd(F_2_300(:));

axis([0 1900 60 315])

l4 = legend([l2 l3 l1],'First Deployment','Second Deployment','$\ell \approx 110$m','location','southeast','fontsize',20)
set(l4,'interpreter','latex')

zz2 = [75 150 300]; ww2 = [wm wm2 wm3]; ss2 = [ws ws2 ws3].^(-2); 

Z = [zz zz2]; W = [ww ww2]; S = [ss ss2];

%%

subplot(122)
% fits from regression as described in text using curve fitting toolbox
l1 = plot(1e6.*0.0001168.*exp(-(55:320).*.003007),55:320,'-.','linewidth',2,'color',[.75 .75 .75])
hold on


load 1_75.mat;
M = 1e6.*M;

[q1,ind] = sort(nanmean(M,1));
qq1 = nanstd(M(:,ind),1);
errorbar(q1,linspace(65,74.5,12),qq1,'horizontal','+k')
hold on
wm = sum(q1./(qq1.^2))./sum((qq1.^(-2)))
ws = sqrt(sum((q1-wm).^2.*(qq1.^(-2)))./sum((qq1.^(-2))))./sqrt(length(q1))
errorbar(wm,70,ws,'horizontal','ok','color',[.59 .07 .39],'markersize',15,'markerfacecolor',[.59 .07 .39],'linewidth',3)

m75 = nanmean(M(:)); s75 = nanstd(M(:));

load 1_150.mat;
M = 1e6.*M;

[q2,ind] = sort(nanmean(M,1));
qq2 = nanstd(M(:,ind),1);
errorbar(q2,linspace(140,149.5,12),qq2,'horizontal','+k')
wm2 = sum(q2./(qq2.^2))./sum((qq2.^(-2)))
ws2 = sqrt(sum((q2-wm2).^2.*(qq2.^(-2)))./sum((qq2.^(-2))))./sqrt(length(q2))
errorbar(wm2,145,ws2,'horizontal','ok','color',[.59 .07 .39],'markersize',15,'markerfacecolor',[.59 .07 .39],'linewidth',3)

m150 = nanmean(M(:)); s150 = nanstd(M(:));

load 1_300.mat;
M = 1e6.*M;

[q3,ind] = sort(nanmean(M,1));
qq3 = nanstd(M(:,ind),1);
errorbar(q3,linspace(290,299.5,12),qq3,'horizontal','+k')
wm3 = sum(q3./(qq3.^2))./sum((qq3.^(-2)))
ws3 = sqrt(sum((q3-wm3).^2.*(qq3.^(-2)))./sum((qq3.^(-2))))./sqrt(length(q3))
l2 = errorbar(wm3,295,ws3,'horizontal','ok','color',[.59 .07 .39],'markersize',15,'markerfacecolor',[.59 .07 .39],'linewidth',3)
set(gca,'ydir','reverse')

set(gca,'TickLabelInterpreter','latex','FontSize',16)
xlabel('areal-mean particle diameter [$\mu$m]','Interpreter','latex','FontSize',20)
box on

zz = [75 150 300]; ww = [wm wm2 wm3]; ss = [ws ws2 ws3].^(-2); 

load 2_75.mat;
M = 1e6.*M;

[q1,ind] = sort(nanmean(M,1));
qq1 = nanstd(M(:,ind),1);
errorbar(q1,linspace(75.5,85,11),qq1,'horizontal','+k')
hold on
wm = sum(q1./(qq1.^2))./sum((qq1.^(-2)))
ws = sqrt(sum((q1-wm).^2.*(qq1.^(-2)))./sum((qq1.^(-2))))./sqrt(length(q1))
errorbar(wm,80,ws,'horizontal','ok','color',[0.8477    0.3281    0.0977],'markersize',15,'markerfacecolor',[0.8477    0.3281    0.0977],'linewidth',3)

m75 = nanmean(M(:)); s75 = nanstd(M(:));

load 2_150.mat;
M = 1e6.*M;

[q2,ind] = sort(nanmean(M,1));
qq2 = nanstd(M(:,ind),1);
errorbar(q2,linspace(150.5,160,11),qq2,'horizontal','+k')
wm2 = sum(q2./(qq2.^2))./sum((qq2.^(-2)))
ws2 = sqrt(sum((q2-wm2).^2.*(qq2.^(-2)))./sum((qq2.^(-2))))./sqrt(length(q2))
errorbar(wm2,155,ws2,'horizontal','ok','color',[0.8477    0.3281    0.0977],'markersize',15,'markerfacecolor',[0.8477    0.3281    0.0977],'linewidth',3)

m150 = nanmean(M(:)); s150 = nanstd(M(:));

load 2_300.mat;
M = 1e6.*M;

[q3,ind] = sort(nanmean(M,1));
qq3 = nanstd(M(:,ind),1);
errorbar(q3,linspace(300.5,310,11),qq3,'horizontal','+k')
wm3 = sum(q3./(qq3.^2))./sum((qq3.^(-2)))
ws3 = sqrt(sum((q3-wm3).^2.*(qq3.^(-2)))./sum((qq3.^(-2))))./sqrt(length(q3))
l3 = errorbar(wm3,305,ws3,'horizontal','ok','color',[0.8477    0.3281    0.0977],'markersize',15,'markerfacecolor',[0.8477    0.3281    0.0977],'linewidth',3)
set(gca,'ydir','reverse')

set(gca,'TickLabelInterpreter','latex','FontSize',16)
xlabel('volume-mean particle diameter [$\mu$m]','Interpreter','latex','FontSize',20)
box on
axis([0 120 60 315])

l4 = legend([l2 l3 l1],'First Deployment','Second Deployment','$\ell \approx 330$m','location','northwest','fontsize',20)
set(l4,'interpreter','latex')

zz2 = [75 150 300]; ww2 = [wm wm2 wm3]; ss2 = [ws ws2 ws3].^(-2); 

Z = [zz zz2]; W = [ww ww2]; SS = [ss ss2];

cd ../code