% =============================================
% M-file to process LISST-100X data "by hand" instead of using LISST.exe
%
% INPUT: zsc-file (*.asc), profile data (*.dat)
% OUTPUT: mat-file with fully calibrated VD [uL/L] data, binned to 2m
%       One mat-file is created for each cruise
% M-files needed:
%       getscat.m, invert.p, and vdcorr.m from Sequoia
%
% A. White, OSU/CEOAS, May 2014
% prior processing converted from dat to log using lisst.exe
% =============================================

clear all
close all
clc

    subdirout=dir(['*.LOG']);
    subdiroutcell=struct2cell(subdirout);
    filelist=subdiroutcell(1,:);
    %filelist={'2C75_1.log'};
for i = 1:length(filelist);
    clearvars -EXCEPT i filelist;
    close all
    clc;
    
    f = filelist{i};

inversion_type= 1; %('Which inversion would you like to use?  1=sphere, 2=random, 3=n 1.17 ... ');
fzsc = ('calavg_dep1.asc'); 
ringareafile = ('Ringarea_1285.asc'); %ring area same for 1285 and 1421


switch inversion_type
    case 1
        x = 1.25; %lower limit for first size range for type B, spherical particles
    case 2
        x = 1.00; %lower limit for first size range for type B, randomly shaped particles
    case 3
        x = 1.25; %lower limit for first size range for type B, n=1.17
end

% get diameters 
    rho=200^(1/32);
    bins(:,1) = x*rho.^([0:31]); %lower limit
    bins(:,2) = x*rho.^([1:32]); % upper limit
    bins(:,3) = sqrt(bins(:,1).*bins(:,2)); %mid-point
    bins(:,4) = bins(:,2) - bins(:,1); %width

dias = bins(:,3)';
clear bins rho x

% Need volume conversion coefficient, which changes with calibration
        VCC = 31936;     % LISST SN 1421 after calibration in MAR2019; % from InstrumentData.txt, changes with factory calibration
        flref = 773;     % from element 36 in factory_zsc file

%% Select file

        %cast = uigetfile(f);
        cast = f;
        [scat,tau,zsc_out,data_out,cscat] = getscat(cast,fzsc,1,ringareafile);
        depth = data_out(:,37)./100; % Depth
        mins = fix(data_out(:,40)/100); secs=data_out(:,40)-100*mins; days=fix(data_out(:,39)/100); hours=data_out(:,39)-100*days; %compute time
        time = days+hours/24+mins/(24*60)+secs/(24*60*60); %create decimal date/time
        dhms = [days hours mins secs];
        lref = data_out(:,36); % get laser ref for VD correction
        dv=[repmat(2019,size(dhms,1),1) dhms]; % date vector
        matlab_date=datenum(dv(:,1),1,0,dv(:,3),dv(:,4),dv(:,5))+dv(:,2);
%% inversion 

% perform scattering inversion to get uncorrected volume distribution
        disp(['Inverting CAST ', cast '     ...']);
        
         switch inversion_type
            case 1
                [vd, dias] = invert(cscat,2,0,0,0,0,1,15); % spherical inversion % 50 iterations default, HOT uses 15
                corr_vd = vdcorr(vd,VCC,flref,lref); % correct for concentration and laser power
           
            case 2
                [vd, dias] = invert(cscat,2,0,1,0,0,1, 'M32x32V_b_rs.ASC', 'H32V_b_rs.ASC', 'Dias32_b_rs.ASC', 15); % random shape inversion
                corr_vd = vdcorr(vd,VCC,flref,lref); % correct for concentration and laser power
            case 3
                [vd, dias]=invert(cscat,2,0,0,0,0,1, 'M32x32V_b_n117.asc', 'H32V_b_n117.asc', 'Dias32_b.asc', 15); % new kernel matrix inversion        end
                corr_vd = vdcorr(vd,VCC,flref,lref); % correct for concentration and laser power
        end % switch

     clear days dhms hours mins sec 

     switch inversion_type
        case 1
            outfile = ['KM1910_',cast(1:end-4),'_sphere.mat'];
        case 2
             outfile = ['KM1910_',cast(1:end-4),'_random.mat']; 
        case 3
             outfile = ['KM1910_',cast(1:end-4),'_n117.mat'];
    end % switch
              save([strcat(cd,'\'),outfile],'cast','cscat','data_out','depth','scat','corr_vd','vd','dias','matlab_date','tau');
 
              
clearvars -EXCEPT f corr_vd cscat data_out dias matlab_date vd tau scat i filelist;             
save(strcat(f(1:end-4),'.mat'),'f','corr_vd','cscat','data_out','dias','matlab_date','vd','tau','scat');
i
end

%{
%% number PDF averaged over 20 iterations
nd = corr_vd./dias.^3;
for i = 1:20;
    nd_int = trapz(dias,nd(i,:));
end
nd_norm = nd./nd_int;
Nd = mean(nd_norm);
Nd_err = sqrt(var(nd_norm));
% cut tails
diasP = dias;%(2:end-1);
NdP = Nd;%(2:end-1);
Nd_errP = Nd_err;%(2:end-1);
plot(diasP,NdP,'k','linewidth',2);
set(gca,'yscale','log','xscale','log')
hold on
plot(diasP,max(NdP-Nd_errP,min(NdP)),'--','color',[.59 .07 .39],'linewidth',2)
plot(diasP,NdP+Nd_errP,'--','color',[.59 .07 .39],'linewidth',2)

axis([1 250 1e-6 0.3])
set(gca,'TickLabelInterpreter','latex','FontSize',20)
xlabel('Equivalent Spherical Diameter [$\mu$m]','Interpreter','latex','FontSize',20)
ylabel('Probability Density [$\mu$m$^{-1}$]','Interpreter','latex','FontSize',20)
title('First Deployment, 300m, Trap L, Replicate 3','Interpreter','latex','FontSize',20)
box on
%}