clear all; close all; clc;
% normalized bias plot

cd ../processed_trap_mat_files

% load data
load 1_75.mat;

% fit & compute normalized bias
for i = 1:12;  
ds = squeeze(D(:,7:27,i));
dm = nanmean(ds,1);
dw = 1./var(ds,1);
sl = l(7:27);
modelFun = @(b,x) abs(b(1)).*x.^(-abs(b(2)));
start = [sum(dm),2];
wnlm = fitnlm(sl,dm,modelFun,start,'Weight',dw);
xi_75_1(i) = wnlm.Coefficients{2,1};
xi_pm_75_1(i) = wnlm.Coefficients{2,2};
r_1_75(:,i) = nanmean(abs(wnlm.Residuals{:,1}./wnlm.Variables{:,2}));
i
end
clearvars -EXCEPT xi* r*;

load 2_75.mat;
for i = 1:11;  
ds = squeeze(D(:,7:27,i));
dm = nanmean(ds,1);
dw = 1./var(ds,1);
sl = l(7:27);
modelFun = @(b,x) abs(b(1)).*x.^(-abs(b(2)));
start = [sum(dm),2];
wnlm = fitnlm(sl,dm,modelFun,start,'Weight',dw);
xi_75_2(i) = wnlm.Coefficients{2,1};
xi_pm_75_2(i) = wnlm.Coefficients{2,2};
r_2_75(:,i) = nanmean(abs(wnlm.Residuals{:,1}./wnlm.Variables{:,2}));
i
end
clearvars -EXCEPT xi* r*;

load 1_150.mat;
for i = 1:12;  
ds = squeeze(D(:,7:27,i));
dm = nanmean(ds,1);
dw = 1./var(ds,1);
sl = l(7:27);
modelFun = @(b,x) abs(b(1)).*x.^(-abs(b(2)));
start = [sum(dm),2];
wnlm = fitnlm(sl,dm,modelFun,start,'Weight',dw);
xi_150_1(i) = wnlm.Coefficients{2,1};
xi_pm_150_1(i) = wnlm.Coefficients{2,2};
r_1_150(:,i) = nanmean(abs(wnlm.Residuals{:,1}./wnlm.Variables{:,2}));
i
end
clearvars -EXCEPT xi* r*;

% note that there is one outlier (150m, trap G, first deployment), which is
% driven entirely by the smallest considered bin, so we remove that bin for
% that specific trap (comment this section out & the trap's normalized bias
% beomes 33%)
load 1_150.mat;
for i = 7;  
ds = squeeze(D(:,8:27,i));
dm = nanmean(ds,1);
dw = 1./var(ds,1);
sl = l(8:27);
modelFun = @(b,x) abs(b(1)).*x.^(-abs(b(2)));
start = [sum(dm),2];
wnlm = fitnlm(sl,dm,modelFun,start,'Weight',dw);
xi_150_1(i) = wnlm.Coefficients{2,1};
xi_pm_150_1(i) = wnlm.Coefficients{2,2};
r_1_150(:,i) = nanmean(abs(wnlm.Residuals{:,1}./wnlm.Variables{:,2}));
i
end
clearvars -EXCEPT xi* r*;

load 2_150.mat;
for i = 1:11;  
ds = squeeze(D(:,7:27,i));
dm = nanmean(ds,1);
dw = 1./var(ds,1);
sl = l(7:27);
modelFun = @(b,x) abs(b(1)).*x.^(-abs(b(2)));
start = [sum(dm),2];
wnlm = fitnlm(sl,dm,modelFun,start,'Weight',dw);
xi_150_2(i) = wnlm.Coefficients{2,1};
xi_pm_150_2(i) = wnlm.Coefficients{2,2};
r_2_150(:,i) = nanmean(abs(wnlm.Residuals{:,1}./wnlm.Variables{:,2}));
i
end
clearvars -EXCEPT xi* r*;

scatter([xi_75_1 xi_150_1 xi_75_2 xi_150_2],[r_1_75 r_1_150 r_2_75 r_2_150])
xlabel('$\xi$','interpreter','latex')
ylabel('normalized bias')

cd ../code