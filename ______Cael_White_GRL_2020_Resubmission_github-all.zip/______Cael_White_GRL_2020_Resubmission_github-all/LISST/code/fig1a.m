close all; clear all; clc;

cd ../processed_trap_mat_files

% choose deployment and depth
load 1_150.mat;

l = 1e6.*l(1:end);
D = D(:,1:end,:);
for i = 1:12;
    for j = 1:60;
    loglog(logspace(log10(3.38),log10(109.2),21),D(j,7:27,i));
    hold on
    end
end
axis([3.07 120 10.^(3.7) 1e9])
plot(3.38e0+0.*logspace(-6,0,1000),logspace(-6,0,1000),'--k')
plot(1.092e2+0.*logspace(-6,0,1000),logspace(-6,0,1000),'--k')
set(gca,'ticklabelinterpreter','latex','fontsize',16)
box on
title('First Deployment, 150m, All Traps','interpreter','latex')
xlabel('Equivalent Spherical Diameter [$\mu$m]','interpreter','latex')
ylabel('Particle Concentration, \#/L/$\mu$m','Interpreter','latex')
axis square

cd ../code