clear all; close all; clc;

% load LISST profiles of xi

cd ../processed_profile_mat_files;
load xi2.mat;
load xi4.mat;
load xi6.mat;
z = [z2; z4; z6]'; x = [x2 x4 x6]; p = [p2 p4 p6];
clear *2 *4 *6;
cd ../code;

% bin vertically
for j = 1:14;
zz = z(z>(10.*j-5) & z<(10.*j+5));
xx = x(z>(10.*j-5) & z<(10.*j+5));
pp = p(z>(10.*j-5) & z<(10.*j+5)); 
xx(pp>1) = NaN;
pp(pp>1) = NaN;
xx(pp==0) = NaN;
pp(pp==0) = NaN;
X(j) = nansum(xx.*pp.^(-2))./nansum(pp.^(-2));
U(j) = sqrt(nansum((X(j)-xx).^2.*pp.^(-2))./nansum(pp.^(-2)))./sqrt(length(xx));
u(j) = sqrt(nansum((X(j)-xx).^2.*pp.^(-2))./nansum(pp.^(-2)));
end
z_p = 10:10:140;
xi_p = X;
xi_p_pm = u;

clearvars -EXCEPT z_p xi_p xi_p_pm;

% input xi & uncertainty values manually from xi-estimating code
z_lt = [75 150 300];
xi_lt1 = [2.042 1.944 2.296];
xi_lt2 = [2.087 1.998 2.271];
xi_lt1pm = [.014 .016 .026];
xi_lt2pm = [.0187 .017 .025];
	
xi_s5 = [3.2341 3.0862 3.3451];
xi_s5pm = [.1462 .1733 .1391];
xi_s75 = [3.3417 3.1866 3.3569];
xi_s75pm = [.2119 .1735 .1920];
xi_s150 = [2.8828 2.9287 2.7227];
xi_s150pm = [.1879 .2341 .1749];

xi_iu = [3.1766];
xi_iupm = [0.0172];
xi_iustd = [.3656];

z_it = [75 150 300];
xi_it1 = [1.9431 1.8842 1.9580];
xi_it1pm = [.0503 .0394 .0366];
xi_it2 = [2.2425 1.9882 2.0452];
xi_it2pm = [.0455 .0431 .0595];

%% plot

e1 = errorbar(xi_p,z_p,xi_p_pm./sqrt(3),'horizontal','ok','color',1./256*[230 158 161],'markersize',9,'markerfacecolor',1./256*[230 158 161],'linewidth',3)
set(gca,'ydir','reverse')
hold on
axis([1.8 3.4 0 315])

xi5 = sum(xi_s5.*xi_s5pm.^(-2))./sum(xi_s5pm.^(-2));
xi5u = sqrt(sum((xi5-xi_s5).^2.*xi_s5pm.^(-2))./sum(xi_s5pm.^(-2)))./sqrt(3);
e3 = errorbar(xi5,5,xi5u,'horizontal','ok','color',1./256.*[77 91 40],'markersize',11,'markerfacecolor',1./256.*[77 91 40],'linewidth',3)

xi75 = sum(xi_s75.*xi_s75pm.^(-2))./sum(xi_s75pm.^(-2));
xi75u = sqrt(sum((xi75-xi_s75).^2.*xi_s75pm.^(-2))./sum(xi_s75pm.^(-2)))./sqrt(3);
errorbar(xi75,75,xi75u,'horizontal','ok','color',1./256.*[77 91 40],'markersize',11,'markerfacecolor',1./256.*[77 91 40],'linewidth',3)

xi150 = sum(xi_s150.*xi_s150pm.^(-2))./sum(xi_s150pm.^(-2));
xi150u = sqrt(sum((xi150-xi_s150).^2.*xi_s150pm.^(-2))./sum(xi_s150pm.^(-2)))./sqrt(3);
errorbar(xi150,150,xi150u,'horizontal','ok','color',1./256.*[77 91 40],'markersize',11,'markerfacecolor',1./256.*[77 91 40],'linewidth',3)

e4 = errorbar(xi_it1,z_it-7.5,xi_it1pm,'horizontal','^k','color',1./256*[183 129 95],'markersize',9,'markerfacecolor',1./256*[183 129 95],'linewidth',3)
errorbar(xi_it2,z_it-2.5,xi_it2pm,'horizontal','^k','color',1./256*[183 129 95],'markersize',9,'markerfacecolor',1./256*[183 129 95],'linewidth',3)

e5 = errorbar(xi_lt1,z_lt+2.5,xi_lt1pm,'horizontal','ok','color',1./256*[219 67 114],'markersize',9,'markerfacecolor',1./256*[219 67 114],'linewidth',3)
errorbar(xi_lt2,z_lt+7.5,xi_lt2pm,'horizontal','ok','color',1./256*[219 67 114],'markersize',9,'markerfacecolor',1./256*[219 67 114],'linewidth',3)

e2 = errorbar(xi_iu,7,xi_iustd./sqrt(452),'horizontal','^k','color',1./256.*[246 200 62],'markersize',11,'markerfacecolor',1./256.*[246 200 62],'linewidth',3)

set(gca,'TickLabelInterpreter','latex','FontSize',16)
xlabel('power-law exponent $\xi$','Interpreter','latex','FontSize',20)
ylabel('depth [m]','Interpreter','latex','FontSize',20)
box on
lgd = legend([e1 e2 e3 e4 e5],'LISST profiles','IFCB time series','LISST suspended','IFCB traps','LISST traps','location','southeast') 
set(lgd,'interpreter','latex')
text(2,290,'*','interpreter','latex','fontsize',20)