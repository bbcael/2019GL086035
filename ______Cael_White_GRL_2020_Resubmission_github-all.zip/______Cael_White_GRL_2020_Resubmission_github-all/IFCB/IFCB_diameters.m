close all; clear all; clc;

% which data to consider; features_t is the time series, features_1and2 is
% the sediment trap deployments
cd features_1and2;

subdirout=dir(['*.csv']);
subdiroutcell=struct2cell(subdirout);
filelist=subdiroutcell(1,:);

for q = 1:(length(filelist));
f = csvread(char(filelist(q)),1,2);
v(1:size(f,1),q) = f(:,1)./2.63.^3;
l(1:size(f,1),q) = f(:,7);
end
l = (6./pi.*v).^(1/3);
l(l==0) = NaN;
a = pi.*l.^2;
v(l==NaN) = NaN;
clearvars -EXCEPT v l a;

for q = 1:size(l,2);
    dv(q) = nansum(l(:,q).*v(:,q))./nansum(v(:,q));
    sv(q) = nansum((l(:,q)-dv(q)).*v(:,q))./nansum(v(:,q));
    da(q) = nansum(l(:,q).*a(:,q))./nansum(a(:,q));
    sa(q) = nansum((l(:,q)-da(q)).*a(:,q))./nansum(a(:,q));
    dn(q) = nanmean(l(:,q));
    sn(q) = nanstd(l(:,q));
end


Dv = sum(dv./sv.^2)./sum(sv.^(-2))
Uv = sqrt(sum((Dv-dv).^2.*(sv.^(-2)))./sum((sv.^(-2))))./sqrt(length(sv));
Da = sum(da./sa.^2)./sum(sa.^(-2))
Ua = sqrt(sum((Da-da).^2.*(sa.^(-2)))./sum((sa.^(-2))))./sqrt(length(sa));
Dn = sum(dn./sn.^2)./sum(sn.^(-2))
Un = sqrt(sum((Dn-dn).^2.*(sn.^(-2)))./sum((sn.^(-2))))./sqrt(length(sn));

cd ..