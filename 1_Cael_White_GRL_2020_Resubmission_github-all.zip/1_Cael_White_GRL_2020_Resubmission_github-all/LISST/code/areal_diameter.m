close all; clear all; clc;

% this is the code used to calculate the areal diameters. 

cd ../sed_trap_mat_files;

subdirout=dir(['*2*75*.mat']);
subdiroutcell=struct2cell(subdirout);
filelist=subdiroutcell(1,:);

for q = 1:(length(filelist)./3);
    clearvars -EXCEPT q filelist A AA;
    close all

load(filelist{(3*(q-1)+1)});
disp(filelist{(3*(q-1)+1)});
l = 1e-6.*dias;
l = l(7:27);
corr_vd = corr_vd(:,7:27);
v1 = 1e-6.*corr_vd(1:20,:);
vn1 = 3./2.*v1./l;
a1 = sum(l.*vn1,2)./sum(vn1,2);
load(filelist{(3*(q-1)+2)});
disp(filelist{(3*(q-1)+2)});
corr_vd = corr_vd(:,7:27);
v2 = 1e-6.*corr_vd(1:20,:);
vn2 = 3./2.*v2./l;
a2 = sum(l.*vn2,2)./sum(vn2,2);
load(filelist{(3*(q-1)+3)});
disp(filelist{(3*(q-1)+3)});
corr_vd = corr_vd(:,7:27);
v3 = 1e-6.*corr_vd(1:20,:);
vn3 = 3./2.*v3./l;
a3 = sum(l.*vn3,2)./sum(vn3,2);
A = [a1; a2; a3];
%clearvars -EXCEPT A AA l q filelist;


AA(:,q) = A;

end

clearvars -EXCEPT AA l;

cd ../code